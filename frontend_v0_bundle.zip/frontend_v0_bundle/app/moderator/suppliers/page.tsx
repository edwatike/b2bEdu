export { default } from "../../suppliers/page"
