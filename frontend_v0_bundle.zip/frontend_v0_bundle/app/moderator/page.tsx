"use client"

export { default } from "./page-optimized"
